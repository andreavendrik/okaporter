<?php
/* deprecated functions that are slowly being phased out */



